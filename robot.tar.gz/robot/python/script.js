var robot = {
	// укажи вот тут правильные номера портов (и в скрипте питона тоже не забудь)
	ports: {
		up: 11,
		right: 8,
		left: 25,
		down: 9
	},
	ready: function() {
		console.log('started');
		$('#up, #right, #left, #right').on({
			mousedown: robot.start,
			mouseup: robot.end
		});
	},
	start: function() {

		robot.send(this.id, 1);
	},
	end: function() {
		robot.send(this.id, 0);
	},
	send: function(port, value) {
		$.ajax({
			type: 'POST',
			url: '/GPIO/' + robot.ports[port] + '/value/' + value
		});
	}
};

$(document).ready(robot.ready);