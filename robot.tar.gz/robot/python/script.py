import webiopi

webiopi.setDebug() # эту строчку можно удалить если все норм
GPIO = webiopi.GPIO

#поставь тут номера портов (и в JS тоже не забудь)
UP      = 11
LEFT    = 8
RIGHT   = 25
DOWN    = 9

def setup():
    GPIO.setFunction(UP, GPIO.OUT)
    GPIO.setFunction(LEFT, GPIO.OUT)
    GPIO.setFunction(RIGHT, GPIO.OUT)
    GPIO.setFunction(DOWN, GPIO.OUT)

def destroy():
    GPIO.setFunction(UP, GPIO.IN)
    GPIO.setFunction(LEFT, GPIO.IN)
    GPIO.setFunction(RIGHT, GPIO.IN)
    GPIO.setFunction(DOWN, GPIO.IN)
